#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Passive Picker v3.0 - customize which armour passives are active
================================================================

WHY THIS TOOL EXISTS
--------------------
A Helldivers 2 `.patch_0` is a binary archive. Inside it, the Lua is wrapped
in a LENGTH-PREFIXED envelope:

    u32 body_len      <-- the loader compiles exactly this many bytes
    u32 version
    Lua bytes ...

So if you edit the Lua text and save it back without also correcting
`body_len`, the loader still reads the OLD byte count. Everything past that
point is silently dropped, which chops the closing `end` off the last
function and the mod fails to load with something like:

    passive_picker_v3.lua:958: 'end' expected (to close 'function' at
    line 954) near '<eof>'

That is the ONLY thing that breaks hand edits. The mod's own code does not
care how many passives you enable - one, thirty-one, or none all work.

This tool owns the envelope, so you never have to think about it.

USAGE
-----
  # 1. Pull the editable Lua out of the shipped mod (zip or .patch_0):
  python passive_picker.py extract "Passive Picker v3.0.zip"

  # 2. Edit the .lua file it writes. Comment out passives you do NOT want,
  #    and/or change the 'trigger_perk = N' line. Then:

  # 3. Repack into a loadable .patch_0 (and a fresh installable .zip):
  python passive_picker.py build passive_picker_config.lua --zip "My Picker.zip"

  # Already edited the .patch_0 in place by hand? Repair its envelope:
  python passive_picker.py fix 9ba626afa44a3aa3.patch_0 --zip "My Picker.zip"

  # Just inspect one without changing it:
  python passive_picker.py check "Passive Picker v3.0.zip"

No third-party packages are required. If `lupa` happens to be installed the
tool also syntax-checks your Lua before packing.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import struct
import sys
import uuid
import zipfile

# ----------------------------------------------------------------- archive format
MAGIC = 0xF0000011
TYPE = 0xA14E8DFA2CD117E2
ENVELOPE_VERSION = 2
FAMILY = "9ba626afa44a3aa3"
ARCHIVE_NAME = FAMILY + ".patch_0"

DEFAULT_MOD_ID = "mods/mostlycloudy/passive_picker_v3"
DEFAULT_DISPLAY = "Passive Picker v3.0"
GUID_NS = uuid.UUID("6f9619ff-8b86-d011-b42d-00c04fc964ff")

_M = (1 << 64) - 1
_MIX = 0xC6A4A7935BD1E995


def resource_hash(name: str) -> int:
    """MurmurHash64A (seed 0) over the UTF-8 resource path."""
    data = name.encode("utf-8")
    value = len(data) * _MIX & _M
    end = len(data) // 8 * 8
    for (word,) in struct.iter_unpack("<Q", data[:end]):
        word = word * _MIX & _M
        word ^= word >> 47
        value = (value ^ (word * _MIX & _M)) * _MIX & _M
    if data[end:]:
        value = (value ^ int.from_bytes(data[end:], "little")) * _MIX & _M
    value ^= value >> 47
    value = value * _MIX & _M
    return value ^ (value >> 47)


def envelope(body: bytes) -> bytes:
    return struct.pack("<II", len(body), ENVELOPE_VERSION) + body


def make_archive(resources: dict) -> bytes:
    pairs = [(resource_hash(n), r) for n, r in sorted(resources.items())]
    if not pairs:
        raise ValueError("an archive needs at least one resource")
    count = len(pairs)
    offset = (104 + 80 * count + 15) & ~15
    entries, body = bytearray(), bytearray(offset)
    for index, (name_hash, resource) in enumerate(pairs):
        entries += struct.pack("<7Q6I", name_hash, TYPE, offset,
                               0, 0, 0, 0, len(resource), 0, 0, 16, 16, index)
        body += resource
        body += b"\0" * (-len(body) % 16)
        offset = len(body)
    header = struct.pack("<III20sQQ24s", MAGIC, 1, count, b"", offset, 0, b"")
    types = struct.pack("<IIQIIII", 0, 0, TYPE, count, 0, 16, 16)
    body[:104 + len(entries)] = header + types + entries
    return bytes(body)


def parse_archive(data: bytes):
    magic, _, count = struct.unpack_from("<III", data, 0)
    if magic != MAGIC:
        raise ValueError("not a .patch_0 archive (magic 0x%08X, expected 0x%08X)"
                         % (magic, MAGIC))
    total, = struct.unpack_from("<Q", data, 32)
    out = []
    for i in range(count):
        row = data[104 + i * 80: 104 + (i + 1) * 80]
        name, rtype, offset = struct.unpack_from("<3Q", row, 0)
        length, = struct.unpack_from("<I", row, 56)
        body_len, ver = struct.unpack_from("<II", data, offset)
        out.append(dict(name=name, offset=offset, length=length,
                        body_len=body_len, version=ver, total=total))
    return out


def lua_from_archive(data: bytes):
    """Return (stored_body_len, full_lua_text). Reads past body_len on purpose."""
    entries = parse_archive(data)
    if not entries:
        raise ValueError("archive holds no resources")
    e = entries[0]
    raw = data[e["offset"] + 8:]
    raw = raw.rstrip(b"\0")
    return e["body_len"], raw.decode("utf-8"), e


# ----------------------------------------------------------------- zip helpers
def read_any(path: str):
    """Accept a .zip (mod package) or a raw .patch_0. Returns (archive_bytes, manifest|None)."""
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            inner = next((n for n in names if n.endswith(ARCHIVE_NAME)), None)
            if inner is None:
                raise ValueError("no %s inside %s" % (ARCHIVE_NAME, path))
            archive = z.read(inner)
            manifest = None
            if "manifest.json" in names:
                try:
                    manifest = json.loads(z.read("manifest.json").decode("utf-8"))
                except Exception:
                    manifest = None
            return archive, manifest
    return open(path, "rb").read(), None


def write_zip(archive: bytes, out: str, mod_id: str, display: str, description: str):
    guid = str(uuid.uuid5(GUID_NS, mod_id))
    manifest = {
        "Version": 1,
        "Guid": guid,
        "Name": display,
        "Description": " ".join(description.split()),
        "Options": [{"Name": display,
                     "Description": " ".join(description.split()),
                     "Include": ["Addon"]}],
    }
    files = {
        "manifest.json": (json.dumps(manifest, indent=2) + "\n").encode(),
        "Addon/" + ARCHIVE_NAME: archive,
        "Addon/" + ARCHIVE_NAME + ".stream": b"",
        "Addon/" + ARCHIVE_NAME + ".gpu_resources": b"",
    }
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p, content in sorted(files.items()):
            info = zipfile.ZipInfo(p, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, content)
    return guid


# ----------------------------------------------------------------- lua checks
def compile_lua(text: str):
    try:
        from lupa.luajit21 import LuaRuntime
    except Exception:
        return None, "lupa not installed - skipped"
    lua = LuaRuntime(unpack_returned_tuples=True)
    f = lua.eval("function(s,n) local fn,e = loadstring(s,n); return fn ~= nil, e end")
    ok, err = f(text, "passive_picker")
    return ok, err


def strip_marker(text: str, mod_id: str):
    if text.startswith("-- HD2-Addon:"):
        return text.partition("\n")[2]
    return text


def add_marker(text: str, mod_id: str):
    marker = "-- HD2-Addon: " + mod_id + "\n"
    return marker + text


def summarise(text: str):
    """Best-effort report of what the config currently selects."""
    info = {}
    m = re.search(r"trigger_perk\s*=\s*(\d+)", text)
    if m:
        info["trigger_perk"] = int(m.group(1))
    # count active (non-commented) row lines in each table
    rows = stats = 0
    section = None
    for line in text.split("\n"):
        s = line.strip()
        if re.match(r"rows\s*=\s*\{", line):
            section = "rows"
            continue
        if re.match(r"stat_rows\s*=\s*\{", line):
            section = "stats"
            continue
        if s.startswith("},") or s == "}":
            section = None
            continue
        if section and not s.startswith("--") and s.startswith("{"):
            if section == "rows":
                rows += 1
            else:
                stats += 1
    info["rows"] = rows
    info["stat_rows"] = stats
    return info


def describe(text: str, label: str, stored_len=None):
    print("%s" % label)
    if stored_len is not None:
        actual = len(add_marker(strip_marker(text, ""), "").encode("utf-8")) \
            if not text.startswith("-- HD2-Addon:") else len(text.encode("utf-8"))
        print("  envelope body_len : %d" % stored_len)
        print("  actual Lua bytes  : %d" % len(text.encode("utf-8")))
        d = len(text.encode("utf-8")) - stored_len
        if d:
            print("  *** MISMATCH %+d bytes -> the loader would drop the last %d ***"
                  % (d, abs(d)))
        else:
            print("  envelope is CORRECT")
    ok, err = compile_lua(text)
    if ok is None:
        print("  syntax            : %s" % err)
    else:
        print("  syntax            : %s" % ("OK" if ok else "FAIL: %s" % err))
    s = summarise(text)
    print("  trigger_perk      : %s" % s.get("trigger_perk", "?"))
    print("  active rows       : %d passive, %d stat" % (s.get("rows", 0), s.get("stat_rows", 0)))
    return ok


# ----------------------------------------------------------------- commands
def cmd_extract(args):
    archive, manifest = read_any(args.input)
    stored, text, entry = lua_from_archive(archive)
    mod_id = args.mod_id
    if text.startswith("-- HD2-Addon:"):
        mod_id = text.partition("\n")[0].replace("-- HD2-Addon:", "").strip()
    body = strip_marker(text, mod_id)

    out = args.output or "passive_picker_config.lua"
    header = (
        "-- ============================================================\n"
        "-- Passive Picker v3.0 - EDIT THIS FILE\n"
        "-- ============================================================\n"
        "-- Comment out (or delete) the rows of any passive you do NOT want.\n"
        "-- Change 'trigger_perk = N' to choose which armour perk this attaches\n"
        "-- to (the armour you wear must have that perk).\n"
        "--\n"
        "-- When you are done, repack it into a loadable .patch_0 with:\n"
        "--   python passive_picker.py build %s --zip \"My Picker.zip\"\n"
        "-- ============================================================\n"
        % os.path.basename(out)
    )
    payload = header + body
    with open(out, "w", encoding="utf-8", newline="\n") as f:
        f.write(payload)
    print("Extracted         : %s" % args.input)
    describe(text, "Shipped state:", stored)
    print()
    print("Wrote editable Lua: %s (%d bytes, %d lines)"
          % (out, len(payload.encode("utf-8")), payload.count("\n") + 1))
    print()
    print("Next: edit that file, then run")
    print("  python passive_picker.py build %s --zip \"My Picker.zip\"" % out)
    return 0


def cmd_build(args):
    text = open(args.input, encoding="utf-8").read()
    if args.trigger is not None:
        new, n = re.subn(r"trigger_perk\s*=\s*\d+", "trigger_perk = %d" % args.trigger, text)
        if n:
            text = new
            print("Override          : trigger_perk = %d" % args.trigger)
        else:
            print("WARNING: no 'trigger_perk = N' line found to override")
    mod_id = args.mod_id
    body = strip_marker(text, mod_id)
    if args.keep_marker and text.startswith("-- HD2-Addon:"):
        mod_id = text.partition("\n")[0].replace("-- HD2-Addon:", "").strip()

    full = add_marker(body, mod_id)
    ok = describe(full, "Edited config:", len(full.encode("utf-8")))
    if ok is False and not args.force:
        print()
        print("REFUSING to pack: the Lua has a syntax error. Fix it, or pass --force.")
        return 1

    archive = make_archive({mod_id: envelope(full.encode("utf-8"))})
    out = args.output or ARCHIVE_NAME
    with open(out, "wb") as f:
        f.write(archive)
    print()
    print("Wrote patch_0     : %s (%d bytes)" % (out, len(archive)))
    print("  resource        : %s" % mod_id)
    print("  envelope        : body_len=%d (matches the Lua exactly)"
          % len(full.encode("utf-8")))
    if args.zip:
        display = args.name or DEFAULT_DISPLAY + " (customized)"
        guid = write_zip(archive, args.zip, mod_id, display,
                         "Passive Picker v3.0 with a hand-picked set of armour "
                         "passives. Requires Bingus Shared Loader v15+ / API 1.")
        print("Wrote zip         : %s" % args.zip)
        print("  display name    : %s" % display)
        print("  guid            : %s" % guid)
    print()
    print("This .patch_0 now loads: the envelope length matches the text.")
    return 0


def cmd_fix(args):
    archive, manifest = read_any(args.input)
    stored, text, entry = lua_from_archive(archive)
    actual = len(text.encode("utf-8"))
    print("Source            : %s" % args.input)
    print("Stored body_len   : %d" % stored)
    print("Actual Lua bytes  : %d (delta %+d)" % (actual, actual - stored))
    if actual == stored and args.output is None:
        print("Already correct - nothing to fix (use build/extract to change it).")
    ok = describe(text, "Content:", None)
    if ok is False and not args.force:
        print()
        print("REFUSING to pack: your edit has a Lua syntax error. Fix it first.")
        print("(If the error is only the truncation this tool repairs, rerun with --force.)")
        return 1

    mod_id = args.mod_id
    if text.startswith("-- HD2-Addon:"):
        mod_id = text.partition("\n")[0].replace("-- HD2-Addon:", "").strip()
    full = text if text.startswith("-- HD2-Addon:") else add_marker(text, mod_id)

    new_archive = make_archive({mod_id: envelope(full.encode("utf-8"))})
    out = args.output or (os.path.splitext(args.input)[0] + ".fixed.patch_0")
    with open(out, "wb") as f:
        f.write(new_archive)
    print()
    print("Repaired patch_0  : %s (%d bytes)" % (out, len(new_archive)))
    print("  envelope        : body_len=%d" % len(full.encode("utf-8")))
    if args.zip:
        display = args.name or DEFAULT_DISPLAY + " (customized)"
        write_zip(new_archive, args.zip, mod_id, display,
                  "Passive Picker v3.0 with a hand-picked set of armour passives. "
                  "Requires Bingus Shared Loader v15+ / API 1.")
        print("Wrote zip         : %s" % args.zip)
    print()
    print("The content that was previously cut off is now included.")
    return 0


def cmd_check(args):
    archive, manifest = read_any(args.input)
    stored, text, entry = lua_from_archive(archive)
    describe(text, "Check %s:" % args.input, stored)
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(
        prog="passive_picker",
        description="Edit and repack Passive Picker v3.0 without breaking the envelope.")
    p.add_argument("--mod-id", default=DEFAULT_MOD_ID)
    sub = p.add_subparsers(dest="cmd", required=True)

    e = sub.add_parser("extract", help="pull the editable Lua out of a zip or .patch_0")
    e.add_argument("input")
    e.add_argument("-o", "--output")
    e.set_defaults(func=cmd_extract)

    b = sub.add_parser("build", help="pack an edited Lua file into a loadable .patch_0")
    b.add_argument("input", help="edited .lua file")
    b.add_argument("-o", "--output", help="output .patch_0 (default: %s)" % ARCHIVE_NAME)
    b.add_argument("--zip", help="also write an installable mod .zip")
    b.add_argument("--name", help="display name for the zip manifest")
    b.add_argument("--trigger", type=int, help="force trigger_perk = N")
    b.add_argument("--keep-marker", action="store_true",
                   help="keep an existing -- HD2-Addon: line's mod id")
    b.add_argument("--force", action="store_true", help="pack even if the Lua won't compile")
    b.set_defaults(func=cmd_build)

    f = sub.add_parser("fix", help="repair the envelope of a hand-edited .patch_0")
    f.add_argument("input")
    f.add_argument("-o", "--output")
    f.add_argument("--zip", help="also write an installable mod .zip")
    f.add_argument("--name", help="display name for the zip manifest")
    f.add_argument("--force", action="store_true", help="pack even if the Lua won't compile")
    f.set_defaults(func=cmd_fix)

    c = sub.add_parser("check", help="report on a zip or .patch_0 without changing it")
    c.add_argument("input")
    c.set_defaults(func=cmd_check)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())