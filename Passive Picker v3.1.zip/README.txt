=================================================================
Passive Picker v3.0 — HOW TO CUSTOMISE
=================================================================

1. EDIT passive_picker_config.lua file in any text editor

   - Change trigger_perk = N to pick a different armour perk (the
     armour you wear must have that perk).
   - Comment out (--) or delete the rows of any passive you do NOT
     want.  Entire passive groups are clearly labelled.
   - EVERY line of the MOD table lives inside the .patch_0 archive.
     The tool handles the binary envelope for you — you never touch
     it directly.

2. REPACK into a loadable .patch_0 (and a fresh installable zip)

       python passive_picker.py build passive_picker_config.lua --zip "Custom Armor Passives.zip"

   The tool:
     * syntax-checks your Lua (if lupa is installed)
     * wraps it in the correct length-prefixed envelope
     * builds the .patch_0 archive
     * writes a full .zip ready for the mod manager

3. INSTALL the new zip (import into your mod manager), or drop the
   .patch_0 into the game's data folder manually.


Already edited the .patch_0 in a hex editor?
---------------------------------------------------------------
   Run fix instead of extract+build:

       python passive_picker.py fix 9ba626afa44a3aa3.patch_0 --zip "My Fixed.zip"

   This repairs the envelope body_len so the loader reads ALL of
   your edits instead of truncating at the old length.


Why this exists
---------------------------------------------------------------
The .patch_0 is a binary LDLD archive.  Inside it the Lua is wrapped
in a length-prefixed envelope: u32 body_len + u32 version + body.
The game's loader compiles exactly body_len bytes.  If you edit the
Lua bytes directly, body_len becomes stale and the last N bytes of
your edit are silently dropped — cutting off the closing `end` of
whatever function happens to sit there.

The tool owns the envelope, so you never think about it.

Requirements
---------------------------------------------------------------
- Python 3.10+
- lupa (optional, enables syntax checking): pip install lupa

No other dependencies: the archive writer and reader are self-
contained in passive_picker.py.  No DSH skill imports needed.